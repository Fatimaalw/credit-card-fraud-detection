# Credit Card Fraud Detection — Stage 7 Deployment

This folder contains a Streamlit application and the tuned Random Forest model from Stage 6.

## Files
- `app.py` — Streamlit user interface.
- `models/fraud_random_forest.joblib` — fitted Stage 6 Random Forest model and metadata.
- `demo_transaction.json` — one example transaction to test the application.
- `requirements.txt` — Python dependencies.

## Run locally in GitHub Codespaces
Open the repository terminal and run:

```bash
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0
```

Codespaces should offer to open the forwarded port (8501).

## Deploy publicly with Streamlit Community Cloud
1. Push this folder's contents to the root of your GitHub repository (so `app.py`, `requirements.txt`, and `models/` are visible at the repository root).
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Select **Create app**, choose the repository and branch, and set the main file path to `app.py`.
4. Deploy. Streamlit Community Cloud installs packages from `requirements.txt`.
5. Copy the public app URL into the project README and report.

## Important limitations
- The source dataset's `V1`–`V28` variables are anonymised PCA components. They are not ordinary fields such as merchant, card number, location, or device. A production bank needs a secure upstream feature pipeline to generate matching features.
- `Time` is elapsed seconds from the start of the original dataset, not a real-world timestamp. The app derives `Hour_Offset = (Time // 3600) % 24`.
- The app uses the Stage 6 threshold of 0.60.
- Stage 6 test results were PR-AUC 0.7702, precision 83.61%, recall 68.92%, and F1-score 0.7556. The original project goals of PR-AUC >= 0.82 and recall >= 75% were not achieved. This prototype should support analyst review only, not automatic payment blocking.
- The FN:FP cost ratio of 10:1 used to select the threshold is an illustrative assumption, not a bank-approved financial cost model.

## Reproducibility
The included model was refitted on the first 80% of `creditcard_features.csv` using the Stage 6 selected parameters:
`n_estimators=10`, `max_depth=8`, `min_samples_leaf=2`, `max_features='sqrt'`,
`class_weight='balanced_subsample'`, `random_state=42`.
